#!/bin/bash
#SBATCH --ntasks=1
#SBATCH --time=4:05:00
#SBATCH --mem=1000
#SBATCH --job-name=irace_job
#SBATCH --cpus-per-task=16

odir=$(pwd)
export ENROOT_DATA_PATH=$TMPDIR/enrootdir
export ENROOT_CACHE_PATH=$TMPDIR/enrootcache
export ENROOT_RUNTIME_PATH=$TMPDIR/enrootruntime
mkdir -p $ENROOT_DATA_PATH
mkdir -p $ENROOT_CACHE_PATH
mkdir -p $ENROOT_RUNTIME_PATH
cd ~
zstd -d automode.zstd -o $TMPDIR/automode.sqsh
cd $TMPDIR
enroot create -n automode automode.sqsh
ls $ENROOT_DATA_PATH
ls $ENROOT_CACHE_PATH
ls ENROOT_RUNTIME_PATH
cd $odir                
odir=$(pwd)
mv experiment_26 $TMPDIR
bash $odir/task_irace.sh $TMPDIR/experiment_26 outfile.txt
mv $TMPDIR/experiment_26 $odir/experiment_26
odir=$(pwd)
mv experiment_27 $TMPDIR
bash $odir/task_irace.sh $TMPDIR/experiment_27 outfile.txt
mv $TMPDIR/experiment_27 $odir/experiment_27
