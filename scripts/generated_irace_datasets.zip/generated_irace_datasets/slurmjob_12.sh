#!/bin/bash
#SBATCH --ntasks=1
#SBATCH --time=4:05:00
#SBATCH --mem=1000
#SBATCH --job-name=irace_job
#SBATCH --cpus-per-task=16

odir=$(pwd)
export ENROOT_DATA_PATH=$TMPDIR/enrootdir
export ENROOT_CACHE_PATH=$TMPDIR/enrootcache
export ENROOT_RUNTIME_PATH=$TMPDIR/enrootruntime
mkdir -p $ENROOT_DATA_PATH
mkdir -p $ENROOT_CACHE_PATH
mkdir -p $ENROOT_RUNTIME_PATH
cd ~
zstd -d automode.zstd -o $TMPDIR/automode.sqsh
cd $TMPDIR
enroot create -n automode automode.sqsh
ls $ENROOT_DATA_PATH
ls $ENROOT_CACHE_PATH
ls ENROOT_RUNTIME_PATH
cd $odir                
odir=$(pwd)
mv experiment_24 $TMPDIR
bash $odir/task_irace.sh $TMPDIR/experiment_24 outfile.txt
mv $TMPDIR/experiment_24 $odir/experiment_24
odir=$(pwd)
mv experiment_25 $TMPDIR
bash $odir/task_irace.sh $TMPDIR/experiment_25 outfile.txt
mv $TMPDIR/experiment_25 $odir/experiment_25
